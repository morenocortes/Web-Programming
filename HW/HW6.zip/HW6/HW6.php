<html>
  <head>
    <title>Connecting MySQL Server</title>
  </head>
  <body>
  <?php
      $dbhost = '';
      $dbuser = 'moren081';
      $dbpass = 'moren081';
      $conn = mysql_connect($dbhost, $dbuser, $dbpass);
      if(! $conn )
      {
        die('Could not connect: ' . mysql_error());
      }
      mysql_select_db( 'moren081' );

      $sql = "SELECT * FROM teams";

      $retval = mysql_query( $sql, $conn );
      if(! $retval )
      {
        die('Could not get data: ' . mysql_error());
      }
      while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
      {
          echo "TeamID :{$row['teamID']}  <br> ".
          "TeamName: {$row['teamName']} <br> ".
          "StartYear: {$row['startYear']} <br> ".
          "Owner Name: {$row['ownerName']} <br> ".
          "GM Name: {$row['GMName']} <br> ".
          "Coach Name: {$row['coachName']} <br> ".
          "MVP: {$row['MVP']} <br> ".
          "Address: {$row['areaAddress']} <br> ".
          "City: {$row['city']} <br> ".
          "State: {$row['state']} <br> ".
          "Zipcode: {$row['zipcode']} <br> ".
          "Phone: {$row['phone']} <br> ".
          "DivRecord: {$row['divRecord']} <br> ".
          "ConfRecord: {$row['confRecord']} <br> ".
          "--------------------------------<br>";
      }


      echo 'Connected successfully';
      ?>

    <form method="GET">
      <input type="text" name="teamID" autofocus /> <br>
      <button type="submit" value="Search for Team" />Search for Team</button>
    </form>


  <?php
      mysql_close($conn);
      ?>
  </body>
</html>
